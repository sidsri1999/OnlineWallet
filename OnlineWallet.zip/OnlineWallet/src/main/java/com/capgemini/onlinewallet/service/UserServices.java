package com.capgemini.onlinewallet.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.capgemini.onlinewallet.dao.*;
import com.capgemini.onlinewallet.model.*;

public class UserServices {
	
	
Scanner sc = new Scanner(System.in);
	
	public boolean createWallet() {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		HashMap<Integer,WalletUser> wus = DataStorage.getWalletUserStore();
		int size=was.size();
		int userId=size+1;
		
		
		
		System.out.println("Set Password :- ");
		System.out.println("Note --------- Password length should be between 5 to 15 characters");
		System.out.println("               It should contain alphabets, numbers, @ and _");
		String password="";
		int i2=0;
		do {
			i2++;
			password=sc.nextLine();
			if(!Validation.passwordValidation(password)){
				if(i2<3) {
				System.out.println("----------Enter a valid password");
				}else {
					System.out.println("----------You have exceeded the limit");
					return false;
				}
			}else {
				break;
			}
		}while(i2<3);
		
		
		System.out.println("Enter Phone Number :- ");
		String phoneNumber="";
		int i3=0;
		do {
			i3++;
			phoneNumber=sc.nextLine();
			if(!Validation.phoneNumberValidation(phoneNumber)){
				if(i3<3) {
					System.out.println("----------Enter a valid Phone Number");
					System.out.println("Note --------- Do not include +91");
				}else {
					System.out.println("----------You have exceeded the limit");
					return false;
				}
			}else {
				break;
			}
		}while(i3<3);
		
		
		System.out.println("Enter Login Name :- ");
		String loginName="";
		int i4=0;
		do {
			i4++;
			loginName=sc.nextLine();
			if(!Validation.loginNameValidation(loginName)){
				if(i4<3) {
					System.out.println("----------Enter a valid Login Name");
				}else {
					System.out.println("----------You have exceeded the limit");
					return false;
				}
			}else {
				break;
			}
		}while(i4<3);
		
		
		WalletUser wu = new WalletUser(userId, password, phoneNumber, loginName);
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
        String current = now.format(format);
		WalletTransactions wt = new WalletTransactions(1,"Created",current,1000.0,1000.0);
 		ArrayList<WalletTransactions> wtl =new ArrayList<WalletTransactions>();
 		wtl.add(wt);
		WalletAccount wa = new WalletAccount(userId ,1000.0, true, wtl);
		
		int i=size;
		while(i>0) {
			if(wus.get(i).getPhoneNumber().equals(phoneNumber)) {
				System.out.println("----------There is another account linked with this phone number!\n--------Account Creation failed1");
				return false;
			}
			i--;
		}
		wus.put(userId,wu);
		was.put(userId,wa);
		DataStorage.setWalletUserStore(wus);
		DataStorage.setWalletAccountStore(was);
		DataStorage.storeWalletUser();
		DataStorage.storeWalletAccount();
		System.out.println("Account Created Successfully! With User ID :- "+ userId);
		return true;
	}
	
	
	
	
	public boolean AddAmount(int userId) {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		String description="Credit";
		int i = 0;
		
		do {
			i++;
			System.out.println("Enter the money to added :- ");
			String amt="";
			Double amount=0.0;
			int i1=0;
			do {
				try {
					i1++;
					amt=sc.nextLine();
					amount=Double.parseDouble(amt);
					break;
				}catch(NumberFormatException e) {
					if(i1<3) {
						System.out.println("Enter a valid amount");
					}else {
						System.out.println("----------You have exceeded the limit");
						return false;
					}
				}
			}while(i1<3);
			
			if(amount < 0.0) {
				System.out.println("----------Invalid Input!");
			}else if(amount > 100000.0) {
				System.out.println("----------Amount should be less than 100000!");
			}else {
				WalletAccount wa = was.get(userId);
				wa.setAccountBalance(wa.getAccountBalance()+amount);
				wa=transactionUpdate(description, amount, wa);
				was.put(userId,wa);
				DataStorage.setWalletAccountStore(was);
				DataStorage.storeWalletAccount();
				System.out.println("Amount added successfully");
				return true;
			}
			
			if(i<3) {
				System.out.println("please enter a valid data");
			}else {
				System.out.println("----------you have exceeded the limt");
				return false;
			}
		}while(i<3);
		return false;
	}
	
	
	
	
	
	public boolean showBalance(int userId) {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		System.out.println("User ID "+was.get(userId).getAccountId()+ " Having Balance: "+was.get(userId).getAccountBalance() );
		return true;
	}
	
	
	
	
	public boolean transferMoney(int AccountId1) {
		String description1="Credit";
		String description2="Debit";
		System.out.println("Enter reciever's User Id");
		int recUserId=-1;
		int i5=0;
		do {
			i5++;
			int i2=0;
			do {
				i2++;
				String uid=sc.nextLine();
				try {
					recUserId=Integer.parseInt(uid);
					break;
				}catch(NumberFormatException e) {
					if(i2<3) {
						System.out.println("----------Please enter a valid User Id");
					}
					else {
						System.out.println("----------You have exceeded the limit!");
						return false;
					}
				}
			}while(i2<3);
			
			if(recUserId!=AccountId1) {
			
				boolean d =DataStorage.getWalletAccountStore().containsKey(recUserId);
				if(d) {
					break;
				}else {
					System.out.println("There is no account having account id "+recUserId);
				}
			}
			if(i5<3) {
				System.out.println("Please enter a valid reciever Id");
			}else{
				System.out.println("you have exceeded the limit!");
				return false;
			}
		}while(i5<3);
		
		
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
			int k=0;
			System.out.println("Enter the money to be transferred :- ");
			do {
				k++;
				Double amount=0.0;
				int i1=0;
				do {
					i1++;
					String amt=sc.nextLine();;
					try {
						amount=Double.parseDouble(amt);
						break;
					}catch(NumberFormatException e) {
						if(i1<3) {
							System.out.println("----------Enter a valid amount");
						}else{
							System.out.println("----------You have exceeded the limit");
							return false;
						}
					}
				}while(i1<3);
				WalletAccount sender=was.get(AccountId1);
				WalletAccount reciever=was.get(recUserId);
				if(amount<1.0) {
					System.out.println("----------Invalid Amount!");
				}
				else if(amount>sender.getAccountBalance()) {
					System.out.println("----------Insufficient Funds!");
				}else{
					sender.setAccountBalance(sender.getAccountBalance()-amount);
					reciever.setAccountBalance(reciever.getAccountBalance()+amount);
					sender=transactionUpdate(description2, amount, sender);
					reciever=transactionUpdate(description1, amount, reciever);
					was.put(sender.getAccountId(), sender);
					was.put(reciever.getAccountId(), reciever);
					DataStorage.setWalletAccountStore(was);
					DataStorage.storeWalletAccount();
					System.out.println("Amount Successfully Transferred");
					System.out.println("Remaining Amount "+(sender.getAccountBalance()));
					return true;
				}
				if(k<3) {
					System.out.println("Please enter a valid amount");
				}else {
					System.out.println("Sorry you have exceeded the limit!");
					return false;
				}
			}while(k<3);
		return false;
	}
	
	
	
	
	
	
	public WalletAccount transactionUpdate(String description,Double amount,WalletAccount wa) {
		ArrayList<WalletTransactions> transactionH = wa.getTransactionHistory();
		int tid = transactionH.size()+1;
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
        String current = now.format(format);
		WalletTransactions wt = new WalletTransactions(tid,description,current,amount,wa.getAccountBalance());
		transactionH.add(wt);
		wa.setTransactionHistory(transactionH);
		return wa;
	}
	
	public boolean viewProfile(int userID) {
		WalletUser wu = DataStorage.getWalletUserStore().get(userID);
		System.out.println("1. User ID      : "+userID+"\n2. Name         : "+wu.getLoginName()+"\n3. Phone Number : "+wu.getPhoneNumber());
		return true;
	}
	
	public boolean viewAccount(int userID) {
		WalletAccount wa = DataStorage.getWalletAccountStore().get(userID);
		System.out.println("1. Account ID : "+userID+"\n2. Account Balance : "+wa.getAccountBalance());
		System.out.println("Press T for getting transaction history");
		String t=sc.nextLine();
		if(t.equalsIgnoreCase("t")) {
			ArrayList<WalletTransactions> alt = wa.getTransactionHistory();
			System.out.println("\n***************    Transaction  Details    ***************");
			for(WalletTransactions wt : alt) {
				System.out.println("Trans. Id : "+wt.getTransactionId()+"  Type : "+wt.getDescription()+"  Date & Time : "+wt.getDateOfTransaction()+"  Trans. Amount : "+wt.getAmount()+"  Balance : "+wt.getAccountBalance());
			}
		}
		return true;
	}
	
	
	

}
