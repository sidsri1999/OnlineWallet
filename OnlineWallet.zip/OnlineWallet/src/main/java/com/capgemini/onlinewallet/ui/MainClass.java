package com.capgemini.onlinewallet.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import com.capgemini.onlinewallet.dao.DataStorage;
import com.capgemini.onlinewallet.model.WalletAccount;
import com.capgemini.onlinewallet.model.WalletUser;
import com.capgemini.onlinewallet.service.*;

public class MainClass {
	
	
	
	public static void main(String[] args) {
		
			Scanner sc = new Scanner(System.in);
			DataStorage.extractWalletUser(); 
			DataStorage.extractWalletAccount();
			NormalServices ns = new NormalServices();
			UserServices us =new UserServices();
			String c="1";
			do {
					
					
					
					switch(ns.startMenuUser()) {
						case 1:	
							ns.startMenuUser2();
							System.out.println();
							c=ns.backMenu();
							break;
						case 2:
							us.createWallet();
							System.out.println();
							c=ns.backMenu();
							break;
						case 3:
							c="3";
							break;
						default: 
							System.out.println("Error 404!");
					}
					
			}while(c.equals("1"));
			
			if(c.equals("3") || c.equals("2")) {
				System.out.println("See You Soon.................");
			}
			
			DataStorage.storeWalletUser();
			DataStorage.storeWalletAccount();
			
		
			
//			try {
//				File f = new File("C:\\Storage\\StoreWalletUser.txt");
//				FileOutputStream file = new FileOutputStream(f);
//				ObjectOutputStream out = new ObjectOutputStream(file);
//				out.writeObject(new HashMap<Integer,WalletUser>());
//				out.close();
//				file.close();
//				System.out.println("Thanks");
//			} catch (Exception e) {
//				System.out.println(e);
//			} 
//			try {
//				File f = new File("C:\\Storage\\StoreWalletAccount.txt");
//				FileOutputStream file = new FileOutputStream(f);
//				ObjectOutputStream out = new ObjectOutputStream(file);
//				out.writeObject(new HashMap<Integer,WalletAccount>());
//				out.close();
//				file.close();
//				System.out.println("Thanks");
//			} catch (Exception e) {
//				System.out.println(e);
//			}
			
			
		}
}