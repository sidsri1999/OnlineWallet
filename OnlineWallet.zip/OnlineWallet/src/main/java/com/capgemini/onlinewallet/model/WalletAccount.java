package com.capgemini.onlinewallet.model;

import java.io.Serializable;
import java.util.*;

public class WalletAccount implements Serializable{
	
	private int AccountId;
	private Double AccountBalance;
	private boolean status;
	ArrayList<WalletTransactions> transactionHistory;
	
	
	
	public WalletAccount(int accountId, Double accountBalance, boolean status, ArrayList<WalletTransactions> transactionHistory) {
		super();
		AccountId = accountId;
		AccountBalance = accountBalance;
		this.status = status;
		this.transactionHistory = transactionHistory;
	}
	public int getAccountId() {
		return AccountId;
	}
	public void setAccountId(int accountId) {
		AccountId = accountId;
	}
	public Double getAccountBalance() {
		return AccountBalance;
	}
	public void setAccountBalance(Double accountBalance) {
		AccountBalance = accountBalance;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public ArrayList<WalletTransactions> getTransactionHistory() {
		return transactionHistory;
	}
	public void setTransactionHistory(ArrayList<WalletTransactions> transactionHistory) {
		this.transactionHistory = transactionHistory;
	}
	@Override
	public String toString() {
		return "WalletAccount [AccountId=" + AccountId + ", AccountBalance=" + AccountBalance + ", status=" + status
				+ ", transactionHistory=" + transactionHistory + "]";
	}
	
	

}
